import pygame
import random

# Иницијализација на PyGame
pygame.init()

# Параметри за прозорецот на играта
FPS = 60
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Space Scavenger")

background_image = pygame.image.load("gameBackground.png")  # background
background_image = pygame.transform.scale(background_image, (800, 600))

# Бои
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

# Лоадирање на ресурси
pygame.mixer.music.load("background_music.wav")
pygame.mixer.music.set_volume(0.5)
pygame.mixer.music.play(-1, 0.0)

collect_sound = pygame.mixer.Sound("clash_sound.wav")
collect_sound.set_volume(0.8)

spaceship_image = pygame.image.load("spaceship.png")
asteroid_image = pygame.image.load("asteroid.png")
crystal_image = pygame.image.load("energy_crystal.png")

# Класа за вселенскиот брод
class Spaceship:
    def __init__(self, x, y):
        self.image = pygame.transform.scale(spaceship_image, (60, 60))
        self.rect = self.image.get_rect(center=(x, y))
        self.speed = 15

    def move(self, keys):
        if keys[pygame.K_LEFT] and self.rect.left > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT] and self.rect.right < WIDTH:
            self.rect.x += self.speed
        if keys[pygame.K_UP] and self.rect.top > 0:
            self.rect.y -= self.speed
        if keys[pygame.K_DOWN] and self.rect.bottom < HEIGHT:
            self.rect.y += self.speed

    def draw(self):
        screen.blit(self.image, self.rect)

# Класа за астероид
class Asteroid:
    def __init__(self, x, y, size):
        self.image = pygame.transform.scale(asteroid_image, (size, size))
        self.rect = self.image.get_rect(center=(x, y))
        self.speed = size * 0.2

    def move(self):
        self.rect.y += self.speed
        if self.rect.top > HEIGHT:
            self.rect.y = -self.rect.height
            self.rect.x = random.randint(0, WIDTH)

    def draw(self):
        screen.blit(self.image, self.rect)

# Класа за енергетски кристал
class Crystal:
    def __init__(self, x, y):
        self.image = pygame.transform.scale(crystal_image, (30, 30))
        self.rect = self.image.get_rect(center=(x, y))
        self.speed = 30 * 0.2

    def move(self):
        self.rect.y += self.speed
        if self.rect.top > HEIGHT:
            self.rect.y = -self.rect.height
            self.rect.x = random.randint(0, WIDTH)
    def collect(self, spaceship_rect):
        return self.rect.colliderect(spaceship_rect)

    def draw(self):
        screen.blit(self.image, self.rect)

# Главна игра
def game_loop():
    spaceship = Spaceship(WIDTH // 2, HEIGHT - 50)
    asteroids = []
    energy_crystals = []
    score = 0
    running = True
    clock = pygame.time.Clock()

    while running:
        screen.fill(BLACK)

        # Обработка на настани
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Движење на вселенскиот брод
        keys = pygame.key.get_pressed()
        spaceship.move(keys)

        # Генерирање нови астероиди и кристали
        if random.random() < 0.02:
            asteroids.append(Asteroid(random.randint(0, WIDTH), 0, random.randint(30, 60)))
        if random.random() < 0.01:
            energy_crystals.append(Crystal(random.randint(0, WIDTH), 0))

        # Движење на астероидите
        for asteroid in asteroids:
            asteroid.move()
            asteroid.draw()
            if asteroid.rect.colliderect(spaceship.rect):
                running = False  # Судир со астероид, играта завршува

        # Проверка за собирање на кристали
        for crystal in energy_crystals[:]:
            crystal.move()
            if crystal.collect(spaceship.rect):
                score += 5
                energy_crystals.remove(crystal)
                collect_sound.play()
            else:
                crystal.draw()

        # Рисување на вселенскиот брод
        spaceship.draw()

        # Пишување на резултат
        font = pygame.font.SysFont(None, 36)
        score_text = font.render(f"Score: {score}", True, WHITE)
        screen.blit(score_text, (10, 10))

        pygame.display.flip()
        clock.tick(FPS)

    # Крај на играта
    font = pygame.font.SysFont(None, 72)
    game_over_text = font.render("GAME OVER", True, (255, 0, 0))
    screen.blit(game_over_text, (WIDTH // 2 - 150, HEIGHT // 2))
    pygame.display.flip()
    pygame.time.wait(2000)
    pygame.quit()

# Покрени ја играта
game_loop()
